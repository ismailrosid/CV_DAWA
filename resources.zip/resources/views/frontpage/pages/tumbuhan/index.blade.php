   @extends('layouts.frontpage')

   @section('title', 'Tumbuhan Page')

   @section('content')

       <form action="{{ route('tumbuhan.index') }}" method="GET">
           <!-- Hero Section Begin -->
           <section style="margin-top: 80px;" class="hero hero-normal p-0">
               <div class="container">
                   <div class="row">
                       <div class="col-12">
                           <div class="hero__search">
                               <div class="hero__search__form">
                                   <div class="hero__search__categories">
                                       Semua Kategori
                                       <span class="arrow_carrot-down"></span>
                                   </div>
                                   <input type="text" name="name" placeholder="Cari tumbuhan berdasarkan nama"
                                       value="{{ request('name') }}">
                                   <button type="submit" class="site-btn">CARI</button>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
           </section>
           <div class="container my-3 py-1">
               <hr>
           </div>

           <!-- Hero Section End -->

           <!-- Breadcrumb Section Begin -->
           {{-- <section class="breadcrumb-section set-bg" data-setbg="img/breadcrumb.jpg">
               <div class="container">
                   <div class="row">
                       <div class="col-lg-12 text-center">
                           <div class="breadcrumb__text">
                               <h2>MediPlants</h2>
                               <div class="breadcrumb__option">
                                   <a href="{{ url('/') }}">Beranda</a>
                                   <span>Tumbuhan</span>
                               </div>
                           </div>
                       </div>
                   </div>
               </div>
           </section> --}}
           <!-- Breadcrumb Section End -->

           <!-- Product Section Begin -->
           <section class="product spad p-0 mt-2 pt-2">
               <div class="container">
                   <div class="row">
                       <div class="col-lg-3 col-md-5"
                           style="position: sticky; top: 100px; height: calc(100vh - 100px); overflow-y: auto;">
                           <div class="sidebar">
                               <div class="sidebar__item">
                                   <h4 style=" color: #1c1c1c; font-weight: 700;">Kategori</h4>
                                   <div class="d-flex gap-2 flex-wrap justify-content-between">
                                       @foreach (range('A', 'Z') as $letter)
                                           <a href="{{ route('tumbuhan.index', array_merge(request()->query(), ['letter' => $letter])) }}"
                                               class="pp p-2 rounded text-center d-flex justify-content-center align-items-center  {{ request('letter') == $letter ? 'bg-dark text-white' : '' }}"
                                               style="">
                                               {{ $letter }}
                                           </a>
                                       @endforeach
                                   </div>
                               </div>
                           </div>

                           {{-- Daftar Pustaka --}}
                           <h4 style="color: #1c1c1c; font-weight: 700;  margin-bottom: 30px;">Daftar Pustaka</h4>

                           {{-- Tambahkan Daftar Pustaka dengan checkbox --}}
                           <div class="form-check" style="margin-bottom: 10px;">
                               <input class="form-check-input" type="checkbox" name="reference1" value="1"
                                   id="reference1">
                               <label style="font-size: 0.8rem" class="form-check-label text-justify" for="reference1">
                                   Anonim, 2010, Acuan Sediaan Herbal, Volume Kelima, Edisi Pertama, Badan Pengawas Obat dan
                                   Makanan RI Direktorat Obat Asli Indonesia, Jakarta, hal. 43.
                               </label>
                           </div>
                           <div class="form-check" style="margin-bottom: 10px;">
                               <input class="form-check-input" type="checkbox" name="reference2" value="2"
                                   id="reference2">
                               <label style="font-size: 0.8rem" class="form-check-label text-justify" for="reference2">
                                   Anonim, 2011, Formulatorium Obat Herbal Asli Indonesia, Kementrian Kesehatan Republik
                                   Indonesia, Vol. 1, Direktorat Bina Pelayanan Kesehatan Tradisional, Alternatif dan
                                   Komplementer, Jakarta, hal. 13.
                               </label>
                           </div>
                           <div class="form-check" style="margin-bottom: 10px;">
                               <input class="form-check-input" type="checkbox" name="reference3" value="3"
                                   id="reference3">
                               <label style="font-size: 0.8rem" class="form-check-label text-justify" for="reference3">
                                   Duke, James A. 2002, Handbook of Medicinal Herb, Second Edition, CRC Press, Florida, hal.
                                   294-296.
                               </label>
                           </div>
                           <div class="form-check" style="margin-bottom: 10px;">
                               <input class="form-check-input" type="checkbox" name="reference4" value="4"
                                   id="reference4">
                               <label style="font-size: 0.8rem" class="form-check-label text-justify" for="reference4">
                                   Duke, James A. 1929, Handbook of Phytochemical Constituents of GRAS Herbs And Other
                                   Economic Plants, CRC Press, Florida, hal. 257-259.
                               </label>
                           </div>
                           <div class="form-check" style="margin-bottom: 10px;">
                               <input class="form-check-input" type="checkbox" name="reference5" value="5"
                                   id="reference5">
                               <label style="font-size: 0.8rem" class="form-check-label text-justify" for="reference5">
                                   Gaby, Alan R. M. D. 2006, A–Z guide to drug-herb-vitamin interactions: improve your
                                   health and avoid side effects when using common medications and natural supplements
                                   together, Third Edition, Three Rivers Press, an imprint of the Crown Publishing Group, a
                                   division of Random House, Inc., New York, hal. 63.
                               </label>
                           </div>
                           <div class="form-check" style="margin-bottom: 10px;">
                               <input class="form-check-input" type="checkbox" name="reference6" value="6"
                                   id="reference6">
                               <label style="font-size: 0.8rem" class="form-check-label text-justify" for="reference6">
                                   Gruenwald, J., Brendler, T., Jaenicke, C. (Eds), 2004, PDR for Herbal Medicines, Third
                                   Edition, Medical Economics Company, New Jersey, hal. 302-303.
                               </label>
                           </div>
                       </div>
                       <div class="col-lg-9">
                           <div class="row">
                               <div class="col-6">
                                   <div class="filter__sort">
                                       <span>Urutkan Berdasarkan</span>
                                       <select name="sort_by" onchange="this.form.submit()">
                                           <option value="0" {{ request('sort_by') == '0' ? 'selected' : '' }}>
                                               Default</option>
                                           <option value="az" {{ request('sort_by') == 'az' ? 'selected' : '' }}>Nama:
                                               A-Z</option>
                                           <option value="za" {{ request('sort_by') == 'za' ? 'selected' : '' }}>Nama:
                                               Z-A</option>
                                       </select>
                                   </div>
                               </div>
                               <div class="col-6 d-flex justify-content-end">
                                   <div class="filter__found">
                                       <h6><span>{{ $tumbuhan->count() }}</span> Tumbuhan Ditemukan</h6>
                                   </div>
                               </div>
                           </div>
                           <div class="row mt-3">
                               @foreach ($tumbuhan as $item)
                                   <div class="col-lg-6 col-md-6 col-sm-6">
                                       <div class="blog-box">
                                           <div class="blog-img">
                                               <img class="img-fluid" src="{{ asset('images/blog-img.jpg') }}"
                                                   alt="" />
                                           </div>
                                           <div class="blog-content">
                                               <div class="title-blog">
                                                   <h3 class="text-center mb-1">{{ $item->nama_tumbuhan }}</h3>
                                                   <h6 class="text-center fs-6 font-italic text-muted"
                                                       style="font-size: 0.8rem;">
                                                       {{ $item->nama_latin }}
                                                   </h6>
                                                   <p class="mt-2 text-justify overflow-hidden max-h-20 line-clamp-5">
                                                       {{ $item->sinonim }}
                                                   </p>
                                               </div>
                                               <ul class="option-blog">
                                                   <li>
                                                       <a target=""
                                                           href="{{ route('tumbuhan.show', ['id' => $item->id]) }}">
                                                           <i class="fas fa-eye"></i>
                                                       </a>
                                                   </li>
                                               </ul>
                                           </div>
                                       </div>
                                   </div>
                               @endforeach
                               <div class="col-lg-12 mt-5">
                                   <div class="blog__pagination">
                                       {{-- {{ $tumbuhan->links() }} --}}
                                   </div>
                               </div>
                           </div>
                       </div>
                   </div>


               </div>
           </section>
           <!-- Product Section End -->
           <!-- Tambahkan hidden input untuk category_id -->
           @if (request('letter'))
               <input type="hidden" name="letter" value="{{ request('letter') }}">
           @endif
       </form>
   @endsection
